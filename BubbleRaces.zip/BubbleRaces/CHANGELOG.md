## Version 0.2.0

* Added "disband army" button
* Fixed a bug where the global map speed would not change until the map was loaded/unloaded.

## Version 0.1.0

* Added speed controls for combat, global map, and tactical battles
