﻿using Kingmaker.TextTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BubbleRaces {
    public class ParameterisedTextTemplate : TextTemplate {
        private readonly Func<string, string> gen;

        public ParameterisedTextTemplate(Func<string, string> gen) {
            this.gen = gen;
        }

        public override string Generate(bool capitalized, List<string> parameters) {
            return gen(parameters.FirstOrDefault());
        }
    }
    public class FixedTextTemplate : TextTemplate {
        private readonly Func<string> gen;

        public FixedTextTemplate(Func<string> gen) {
            this.gen = gen;
        }

        public override string Generate(bool capitalized, List<string> parameters) {
            return gen();
        }
    }

    public static class BubbleTemplates {
        private static readonly HashSet<string> Added = new();
        private static void Add(string tag, Func<string> simple) {
            Added.Add(tag);
            TextTemplateEngine.s_TemplatesByTag[tag] = new FixedTextTemplate(simple);
        }
        private static void Add(string tag, Func<string, string> func) {
            Added.Add(tag);
            TextTemplateEngine.s_TemplatesByTag[tag] = new ParameterisedTextTemplate(func);
        }
        public static void AddAll() {
        
        }
        public static void RemoveAll() {
            foreach (var k in Added)
                TextTemplateEngine.s_TemplatesByTag.Remove(k);
        }

    }

}
