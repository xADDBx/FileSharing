﻿namespace BubbleRaces.Config {
    public interface IDisableableGroup {
        bool GroupIsDisabled();
    }
}
