# XUnity.AutoTranslator for Dark Heresy Unity Mod Manager

This is a conventional Dark Heresy Unity Mod Manager project based on the local ToyBox setup. It starts the unmodified XUnity.AutoTranslator 5.6.1 core from UMM, so BepInEx and a second Doorstop bootstrap are not needed.

## Project layout

- `XUnityAutoTranslator.slnx` is the solution.
- `GamePathFinder.props` and `GamePath.props` follow Dark Heresy ToyBox's game-path setup.
- `XUnityAutoTranslator/Info.json` declares the UMM entry point.
- `XUnityAutoTranslator/Classes/Main.cs` contains the UMM lifecycle entry point.
- The environment and logger integrations are separate classes under `Classes/`.

## Build

The project consumes the adjacent XUnity checkout's standard `dist\Developer` and `dist\Translators` outputs. With those present, build `XUnityAutoTranslator.slnx` in Release from Visual Studio or with ordinary MSBuild:

```powershell
msbuild XUnityAutoTranslator.slnx /restore /t:Build /p:Configuration=Release
```

The UMM package is written to:

`XUnityAutoTranslator/bin/Release/XUnityAutoTranslator-5.6.1.zip`

No install or packaging script is used. A normal build only creates the package. To use the same opt-in development deployment pattern as ToyBox, build with `DeployToGame=true`; this copies the package to:

`%USERPROFILE%\AppData\LocalLow\Owlcat Games\WHDH\UnityModManager\XUnityAutoTranslator`

## Configuration

The supplied configuration translates English to Simplified Chinese (`FromLanguage=en`, `Language=zh-CN`). Change `Language` before starting the game if another target language is wanted.

XUnity writes translations below `Translation\{Lang}\Text` in the mod directory. `Alt+0` toggles translated/original text and `Alt+R` reloads translation files.

## Compatibility

- This targets Dark Heresy's managed/Mono player and UMM 0.32.5.
- The package deliberately excludes `0Harmony.dll`, BepInEx, Doorstop DLLs, and `UnityEngine.dll`.
- XUnity installs runtime hooks and is therefore treated as restart-only rather than toggleable or reloadable.

XUnity.AutoTranslator is MIT-licensed. The package includes its license; upstream is at <https://github.com/bbepis/XUnity.AutoTranslator>.
