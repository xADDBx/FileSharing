
BUBBLE BUBBLE BUBBLE

Acknowledgments:  

-   @Balkoth for Buffbot which is the direct inspiration for this
-   Discord members who tested super early broken extra-poop versions!
-   Pathfinder Wrath of The Righteous Discord channel members
-	@Vek17 extra special thanks because this mod is pretty much a copy paste of his to get it off the ground :pray:
-   Join our [Discord](https://discord.gg/bQVwsP7cky)


