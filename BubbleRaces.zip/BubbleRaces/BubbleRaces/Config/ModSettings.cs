﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using static UnityModManagerNet.UnityModManager;

namespace BubbleRaces.Config {
    static class ModSettings {
        public static ModEntry ModEntry;
        public static Fixes Fixes;
        public static AddedContent AddedContent;
        public static Blueprints Blueprints;

        public static Dictionary<string, string> AssetsInBundles = new();
        public static HashSet<string> Bundles = new();

        public static void LoadAllSettings() {
            LoadSettings("Fixes.json", ref Fixes);
            LoadSettings("AddedContent.json", ref AddedContent);
            LoadSettings("Blueprints.json", ref Blueprints);

            LoadAssetLinks();

        }

        private static void LoadAssetLinks() {

            using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("BubbleRaces.Config.my_assets.txt");
            using var reader = new StreamReader(stream);


            while (!reader.EndOfStream) {
                var line = reader.ReadLine().Trim();
                if (line.Length == 0 || line[0] == '#') continue;

                var c = line.IndexOf(':');

                var bundle = line.Substring(c + 1);

                Bundles.Add(bundle);
                AssetsInBundles[line.Substring(0, c)] = bundle;
            }

            Main.Log($"Found {AssetsInBundles.Count} asset links in {Bundles.Count} bundles");

        }

        public static void LoadSettings<T>(string fileName, ref T setting, bool fromFile = false) {
            var assembly = Assembly.GetExecutingAssembly();
            string userConfigFolder = ModEntry.Path + "UserSettings";
            Directory.CreateDirectory(userConfigFolder);
            var resourcePath = $"BubbleRaces.Config.{fileName}";

            StreamReader reader;
            if (fromFile)
                reader = File.OpenText(Path.Combine(userConfigFolder, fileName));
            else {
                Stream stream = assembly.GetManifestResourceStream(resourcePath);
                reader = new StreamReader(stream);
            }

            JsonSerializer serializer = new JsonSerializer {
                NullValueHandling = NullValueHandling.Include,
                Formatting = Formatting.Indented
            };
            var jReader = new JsonTextReader(reader);
            setting = serializer.Deserialize<T>(jReader);

            reader.Close();
            reader.Dispose();

        }

    }
}
