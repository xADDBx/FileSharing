﻿using HarmonyLib;
using System.Linq;
using JetBrains.Annotations;
using Kingmaker;
using Kingmaker.Blueprints.JsonSystem;
using System;
using BubbleRaces.Config;
using BubbleRaces.Utilities;
using UnityModManagerNet;
using UnityEngine;
using Kingmaker.UI.SettingsUI;
using Kingmaker.PubSubSystem;
using System.Collections.Generic;
using Kingmaker.UI;
using System.Reflection;
using Kingmaker.Cheats;
using Kingmaker.DialogSystem.Blueprints;
using Kingmaker.EntitySystem.Entities;
using Kingmaker.EntitySystem;
using Kingmaker.UnitLogic.Parts;
using Kingmaker.View.MapObjects;
using Kingmaker.ElementsSystem;
using Kingmaker.Utility;
using Kingmaker.UI.Log.CombatLog_ThreadSystem;
using Kingmaker.UI.Log.CombatLog_ThreadSystem.LogThreads.Common;
using Kingmaker.Blueprints.Root.Strings.GameLog;
using Kingmaker.UI.MVVM._VM.Tooltip.Templates;
using Kingmaker.Visual.Particles;
using Kingmaker.Designers;
using static Kingmaker.QA.Statistics.ExperienceGainStatistic;
using Kingmaker.UnitLogic.Abilities;
using Kingmaker.UnitLogic.Buffs;
using System.IO;
using Kingmaker.ResourceLinks;
using Kingmaker.UnitLogic.Abilities.Blueprints;
using BubbleRaces.BlueprintCore.Utils;
using TMPro;
using Kingmaker.Controllers.Rest;
using Kingmaker.Blueprints;
using Kingmaker.Modding;
using Kingmaker.BundlesLoading;
using Owlcat.Runtime.Core.Logging;
using Kingmaker.Visual.CharacterSystem;

public class BubbleCL : CharacterColorsProfile { }
public class BubbleEE : EquipmentEntity { }


namespace BubbleRaces {

    public class BubbleSettings {

        private BubbleSettings() { }

        public static UISettingsEntitySliderFloat MakeSliderFloat(string key, string name, string tooltip, float min, float max, float step) {
            var slider = ScriptableObject.CreateInstance<UISettingsEntitySliderFloat>();
            slider.m_Description = Helpers.CreateString($"{key}.description", name);
            slider.m_TooltipDescription = Helpers.CreateString($"{key}.tooltip-description", tooltip);
            slider.m_MinValue = min;
            slider.m_MaxValue = max;
            slider.m_Step = step;
            slider.m_ShowValueText = true;
            slider.m_DecimalPlaces = 1;
            slider.m_ShowVisualConnection = true;

            return slider;
        }

        public static UISettingsGroup MakeSettingsGroup(string key, string name, params UISettingsEntityBase[] settings) {
            UISettingsGroup group = ScriptableObject.CreateInstance<UISettingsGroup>();
            group.Title = Helpers.CreateString(key, name);

            group.SettingsList = settings;

            return group;
        }

        public void Initialize() {
        }

        private static readonly BubbleSettings instance = new();
        public static BubbleSettings Instance { get { return instance; } }
    }


    //[HarmonyPatch(typeof(UISettingsManager), "Initialize")]
    //static class SettingsInjector {
    //    static bool Initialized = false;

    //    [System.Diagnostics.CodeAnalysis.SuppressMessage("CodeQuality", "IDE0051:Remove unused private members", Justification = "harmony patch")]
    //    static void Postfix() {
    //        if (Initialized) return;
    //        Initialized = true;
    //        Main.LogHeader("Injecting settings");

    //        BubbleSettings.Instance.Initialize();

    //        //Game.Instance.UISettingsManager.m_GameSettingsList.Add(
    //        //    BubbleSettings.MakeSettingsGroup("bubble.speed-tweaks", "Bubble speed tweaks",
    //        //        BubbleSettings.Instance.GlobalMapSpeedSlider,
    //        //        BubbleSettings.Instance.InCombatSpeedSlider,
    //        //        BubbleSettings.Instance.OutOfCombatSpeedSlider,
    //        //        BubbleSettings.Instance.TacticalCombatSpeedSlider));
    //    }
    //}



    public static class IListExtensions {
        public static Condition Not(this Condition cond) {
            cond.Not = true;
            return cond;
        }
        public static string ToTag(this string str) {
            return '{' + str + '}';
        }
        /// <summary>
        /// Shuffles the element order of the specified list.
        /// </summary>
        public static void Shuffle<T>(this IList<T> ts) {
            var count = ts.Count;
            var last = count - 1;
            for (var i = 0; i < last; ++i) {
                var r = UnityEngine.Random.Range(i, count);
                var tmp = ts[i];
                ts[i] = ts[r];
                ts[r] = tmp;
            }
        }
    }

    public class DeckTemplate<T> {
        private readonly List<T> all;
        public DeckTemplate(params T[] cards) {
            all = new(cards);
        }
        public DeckTemplate(IEnumerable<T> cards) {
            all = new(cards);
        }

        public Deck<T> Deck => new(all);

    }

    public class Deck<T> {
        private readonly List<T> vals;
        private int Head => vals.Count - 1;
        public bool Empty => vals.Count == 0;

        public T Next => Take(1).FirstOrDefault();

        public Deck(List<T> all) {
            vals = new(all);
            vals.Shuffle();
        }

        public IEnumerable<T> Take(int count) {
            for (int i = 0; i < count && vals.Count > 0; i++) {
                T val = vals[Head];
                vals.RemoveAt(Head);
                yield return val;
            }
        }

        public bool TryPeek(out T val) {
            if (vals.Count == 0) {
                val = default;
                return false;
            } else {
                val = vals[Head];
                return true;
            }
        }
    }

    //public interface IBuilder<T> {
    //    public T Create();
    //}


#if DEBUG
    [EnableReloading]
#endif
    static class Main {
        public static string ModPath;
        private static Harmony harmony;
        public static bool Enabled;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("CodeQuality", "IDE0051:Remove unused private members", Justification = "harmony method")]
        static bool Load(UnityModManager.ModEntry modEntry) {
            harmony = new Harmony(modEntry.Info.Id);
#if DEBUG
            modEntry.OnUnload = OnUnload;
#endif
            try {
                CheatsCommon.SendAnalyticEvents?.Set(false);
                modEntry.OnUpdate = OnUpdate;
                ModSettings.ModEntry = modEntry;
                ModPath = modEntry.Path;
                Main.Log("LOADING");

                BubbleTemplates.AddAll();
                ModSettings.LoadAllSettings();

                UIHelpers.WidgetPaths = new WidgetPaths_1_1();
                harmony.PatchAll();

                if (ResourcesLibrary.BlueprintsCache.m_PackFile != null) {
                    Main.Log("YES initialized");
                    BubbleRacesRoot.Install();
                } else {
                    Main.Log("NO initialized");
                }
            } catch (Exception e) {
                Error(e, "loading");
            }

            return true;
        }


        static void OnUpdate(UnityModManager.ModEntry modEntry, float delta) {
#if DEBUG && BUBBLEDEV
            if (Input.GetKeyDown(KeyCode.D) && (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))) {
                Blueprints.WriteBlueprints("Blueprints.json");
            }
            if (Input.GetKeyDown(KeyCode.L) && (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))) {
                BubbleRacesRoot.Install();
            }
            if (Input.GetKeyDown(KeyCode.B) && (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))) {
                modEntry.GetType().GetMethod("Reload", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(modEntry, new object[] { });
            }
#endif
        }

        static bool OnUnload(UnityModManager.ModEntry modEntry) {
            BubbleTemplates.RemoveAll();
            harmony.UnpatchAll();
            BP.RemoveModBlueprints();
            BubbleRacesRoot.Uninstall();

            return true;
        }

        internal static void LogPatch(string v, object coupDeGraceAbility) {
            throw new NotImplementedException();
        }

        public static void Log(string msg) {
            ModSettings.ModEntry.Logger.Log(msg);
        }
        [System.Diagnostics.Conditional("DEBUG")]
        public static void LogDebug(string msg) {
            ModSettings.ModEntry.Logger.Log(msg);
        }
        public static void LogPatch(string action, [NotNull] IScriptableObjectWithAssetId bp) {
            Log($"{action}: {bp.AssetGuid} - {bp.name}");
        }
        public static void LogHeader(string msg) {
            Log($"--{msg.ToUpper()}--");
        }
        public static void Error(Exception e, string message) {
            Log(message);
            Log(e.ToString());
            PFLog.Mods.Error(message);
        }
        public static void Error(string message) {
            Log(message);
            PFLog.Mods.Error(message);
        }

        //public static void CombatLog(string str, Color col, TooltipBaseTemplate tooltip = null) {
        //    var message = new CombatLogMessage(str, col, PrefixIcon.None, tooltip, tooltip != null);
        //    var messageLog = LogThreadController.Instance.m_Logs[LogChannelType.Common].First(x => x is MessageLogThread);
        //    messageLog.AddMessage(message);
        //}
        //public static void CombatLog(string str) {
        //    CombatLog(str, GameLogStrings.Instance.DefaultColor);
        //}

        static HashSet<string> filtersEnabled = new() {
            //"state",
            //"minority",
            //"rejection",
            "interop",
        };

        static bool suppressUnfiltered = true;

        internal static void Verbose(string v, string filter = null) {
#if true && DEBUG
            if ((filter == null && !suppressUnfiltered) || filtersEnabled.Contains(filter))
                Main.Log(v);
#endif
        }

        internal static void LogNotNull(string v, object obj) {
            Main.Log($"{v} not-null: {obj != null}");
        }

    }

    public struct Weighted<T> : Utilities.IWeighted {
        public int count;
        public T name;

        public Weighted(int count, T name) {
            this.count = count;
            this.name = name;
        }

        public int Weight => count;

        public void Deconstruct(out int count, out T name) {
            count = this.count;
            name = this.name;
        }

        public static implicit operator (int count, T name)(Weighted<T> value) {
            return (value.count, value.name);
        }

        public static implicit operator Weighted<T>((int count, T name) value) {
            return new Weighted<T>(value.count, value.name);
        }

        public override string ToString() {
            return name?.ToString();
        }

    }

    [HarmonyPatch]
    public static class AssetHandler {

        private static Dictionary<string, Shader> shadersByName;

        [HarmonyPatch(typeof(OwlcatModificationsManager), nameof(OwlcatModificationsManager.TryLoadBundle)), HarmonyPrefix]
        public static bool TryLoadBundle(string bundleName, ref AssetBundle __result) {
            if (ModSettings.Bundles.Contains(bundleName)) {
                Main.Log($"Loading bubblebundle: {bundleName}");
                __result = AssetBundle.LoadFromFile(Path.Combine(Main.ModPath, bundleName));

                if (shadersByName == null) {
                    shadersByName = new();
                    shadersByName["Owlcat/Lit"] = new EquipmentEntityLink { AssetId = "1e4cafa72c2a2f5468c83868873f31ec" }.Load(false).BodyParts[0].Material.shader;

                }

                var materials = __result.LoadAllAssets<BubbleMaterialCollection>();
                Main.LogNotNull("materials", materials);
                if (materials != null) {
                    foreach (var materialCollection in materials) {
                        foreach (var material in materialCollection.Materials) {
                            if (material == null) {
                                Main.Log("null material, probably stale asset, skipping");
                                continue;
                            }
                            Main.Log("fixing material: " + material.name);
                            if (material.shader != null)
                                if (shadersByName.TryGetValue(material.shader.name, out var replacement))
                                    material.shader = replacement;
                        }

                    }
                }
                return false;
            }
            return true;
        }

        [HarmonyPatch(typeof(OwlcatModificationsManager), nameof(OwlcatModificationsManager.GetBundleNameForAsset)), HarmonyPrefix]
        public static bool GetBundleNameForAsset(string guid, ref string __result) {
            if (ModSettings.AssetsInBundles.TryGetValue(guid, out var myBundle)) {
                Main.Log($"Re-directing asset with guid: {guid} => bundle: {myBundle}");
                __result = myBundle;
                return false;
            }
            return true;
        }

        [HarmonyPatch(typeof(OwlcatModificationsManager), nameof(OwlcatModificationsManager.GetDependenciesForBundle)), HarmonyPrefix]
        public static bool GetDependenciesForBundle(string bundleName, ref DependencyData __result) {
            if (ModSettings.Bundles.Contains(bundleName)) {
                __result = null;
                return false;
            }
            return true;
        }

    }
    [HarmonyPatch(typeof(AssetBundle))]
    public static class AssetPatcher {
        public static Dictionary<string, Action<UnityEngine.Object>> LoadActions = new();

        //public Object LoadAsset(string name, Type type)
        [HarmonyPatch(nameof(AssetBundle.LoadAsset), typeof(string), typeof(Type)), HarmonyPostfix]
        public static void LoadAsset(string name, ref UnityEngine.Object __result) {
            if (LoadActions.TryGetValue(name, out var action)) {
                Main.Log($"Patching asset on load: {name}");
                action(__result);
            }
        }
    }

    [HarmonyPatch(typeof(BlueprintsCache))]
    public static class OnCacheInit {

        [HarmonyPatch(nameof(BlueprintsCache.Init)), HarmonyPostfix]
        public static void Init() {
            //BubbleRacesRoot.Install();
        }
    }



    [HarmonyPatch(typeof(LogChannel))]
    public static class LOG_BE_QUIET {

        public static HashSet<string> Quiet = new() {
            "Await input module",
            "Await event system",
        };

        [HarmonyPatch("Log"), HarmonyPatch(new Type[] { typeof(string), typeof(object[]) }), HarmonyPrefix]
        public static bool Log(string messageFormat) {
            if (Quiet.Contains(messageFormat))
                return false;
            return true;
        }

    }

}

