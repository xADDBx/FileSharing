This mod was created by Wofsauge and over 40 different people from all around the world!

If you enjoy this mod and want to help on it, check it out on GitHub: https://github.com/wofsauge/External-Item-Descriptions

# Languages
- **Bulgarian**: by TST_Gogo_, Gothika_47
- **Chinese**: by Xheepey87, frto027
- **Czech**: by David Kapitančik. Picus, domcizzz
- **Dutch**: by SomethingMax
- **English**: by Wofsauge, Buurazu, Ma-rcx, AutisticGoat (Kotry), ...
- **French**: by biobak, Nicolas Delvaux
- **German**: by Mirades, Staubgeborener, Jake
- **Greek**: by vanillarat
- **Italian**: by Klyser8, Denkishi, 2G
- **Japanese**: by prefab
- **Korean**: by Blackcreamtea, 리셰(kohashiwakaba)
- **Polish**: by Rickyy, Kennyluz, MERITT, DimonoKingoKongo
- **Portuguese**: by Marcelino Cruz
- **Russian**: by hell2Pay, fly_6, Dezzelshipc and Sekaz
- **Spanish**: by Lidia Arroyo Purroy, MartinFierro, maintained by AutisticGoat (Kotry)
- **Brazilian - Portuguese**: by LuanRoger and NotZin02
- **Turkish**: by Cagdas Salur, Mert Dutal
- **Ukrainian**: by x3xto


# Special Thanks to
- [The Binding of Isaac Wiki](https://bindingofisaacrebirth.fandom.com/wiki/Binding_of_Isaac:_Rebirth_Wiki) and [platinumgod.co.uk](https://platinumgod.co.uk/) for providing useful item descriptions
- Buurazu for all the hard work improving the mod :)
- Kittenchilly for the crane game support, Mod indicators and a lot of code improvements and fixes
- biobak for creating a lot of inline icons and other improvements
- [eyeguy](https://twitter.com/eyeguyart) for creating the astonishing transformation icons
- [adc](https://steamcommunity.com/id/whytefang/) for creating an awesome new language pack and providing ideas for new functionalities
- [CreepSore](https://github.com/CreepSore) for creating the bag of crafting search feature
- [Poyo](https://x.com/Poyomama02) for the great thumbnail art
